package com.example.helloworld

object Singleton {
    fun singletonTest() {
        println("singletonTest is called.")
    }
}