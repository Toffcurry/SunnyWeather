package com.example.recyclerviewtest

class Fruit(val name:String, val imageId: Int)