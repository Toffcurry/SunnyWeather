package com.example.uiwidgettest

/**
 *
 *
 * @author guolin
 * @since 2019-05-20
 */
class Test {

    fun getHello() {

    }

}