package com.example.materialtest

fun printFruits() {
    val fruitList = mutableListOf("Apple", "Banana", "Orange", "Pear", "Grape")
    for (fruit in fruitList) {
        println(fruit)
    }
}