package com.example.materialtest

class Fruit(val name: String, val imageId: Int)